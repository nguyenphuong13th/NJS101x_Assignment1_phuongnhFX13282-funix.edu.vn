const express = require('express')
const router = express.Router()
const loginController = require('../controller/loginController')

router.get('/login',loginController.Login)
router.get('/login/loged-in-screen',loginController.Update)
module.exports = router