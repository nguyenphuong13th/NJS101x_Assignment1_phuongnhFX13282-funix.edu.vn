const employees = require('../models/employees')
const {multipleMongooseToObject} =require('../ultil/mongoose')

class UserController{
    //Get/user
    index(req,res){
        res.render('user')
    }
    //Get/user/register
    Register(req,res,next){
        employees.find({})
        .then (employees=>{
            console.log(employees)
            res.render('registerscreen',
                {employees:multipleMongooseToObject(employees)}
            )})
        .catch (next)

    }
    //Get/user/checkin
    LogIn(req,res,next){
        employees.findOne({
            name:req.body.name,
            password:req.body.password
        })
        .then (employees=>{
            console.log(employees)
            res.render('loginScreen',
                {employees:multipleMongooseToObject(employees)}
            )})
        .catch (next)

    }
    offline(req,res){
        res.render('finish')
    }
    dayOff(req,res){
        res.render('dayoff')
    }
}

module.exports = new UserController
