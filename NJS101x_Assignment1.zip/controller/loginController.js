const employees = require('../models/employees')

class loginController{

    //Get//Login
    Login(req,res){
        res.render('login')
    }
    //Get/user/log-in-screen

    Update(req,res,next){
        res.render('loginscreen/login-screen')
    }

}

module.exports = new loginController
